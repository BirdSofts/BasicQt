﻿// *******************************************************************************************
/// <summary>
/// 
/// </summary>
/// <created>ʆϒʅ,15.09.2019</created>
/// <changed>ʆϒʅ,16.09.2019</changed>
// *******************************************************************************************

#ifndef UTESTS_H
#define UTESTS_H


#include "CppUnitTest.h"


using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest1
{


  TEST_CLASS ( UnitTest1 )
  {
  public:

    TEST_METHOD ( TestMethod1 );
  };


}


#endif //UTESTS_H
